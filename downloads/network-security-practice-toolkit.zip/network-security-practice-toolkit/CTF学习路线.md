# CTF 学习路线

> CTF 是网络安全实战的好入口，按方向逐个突破。

## 主要方向
- Web：网站漏洞（SQL 注入、XSS、文件上传、SSRF 等）
- Pwn：二进制漏洞利用（栈溢出、堆利用）
- Reverse：逆向工程
- Crypto：密码学
- Misc：杂项（隐写、取证、流量分析）
- Mobile：移动安全

## 入门阶段
- 打好基础：Linux、Python、计算机网络、HTTP
- Web 方向：先学 OWASP Top 10，理解常见漏洞原理
- 从简单的 Web 题开始，建立信心
- 学会用搜索引擎和 WriteUp

## 进阶阶段
- 选定 1–2 个主攻方向深入
- 系统刷题，按专题整理
- 学习常用工具（Burp、GDB、IDA、Wireshark）
- 复现经典漏洞，理解原理而非只看答案

## 刷题平台
- 国内：BUUCTF、攻防世界、CTFShow、NSSCTF
- 国外：Hack The Box、TryHackMe、PicoCTF
- 比赛：关注各类 CTF 赛事，以赛促学

## 学习建议
- 写 WriteUp，记录思路和 payload
- 加入战队或学习小组，交流进步
- 定期复盘，形成自己的知识体系
- 不要只刷简单题，适当挑战
